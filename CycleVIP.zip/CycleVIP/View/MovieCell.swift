//
//  MovieCell.swift
//  CycleVIP
//
//  Created by Pedro Silva Dos Santos on 19/10/21.
//

import UIKit

class MovieCell: UITableViewCell {
    
    @IBOutlet private var titleLabel: UILabel!
    @IBOutlet private var yearLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}


extension MovieCell {
    struct ViewProps {
        var title: String
        var year: Int
    }
    
    func render(props: ViewProps) {
        self.titleLabel.text = props.title
        self.yearLabel.text = String(props.year)
    }
}
