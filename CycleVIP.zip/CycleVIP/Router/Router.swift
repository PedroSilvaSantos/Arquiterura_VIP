//
//  Router.swift
//  CycleVIP
//
//  Created by Pedro Silva Dos Santos on 19/10/21.
//

import Foundation
import UIKit

/// <#Description#>
class Router {
    
    /// <#Description#>
    private var navigationController: UINavigationController
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func startNavigation() {
        self.showMoviesListView()
    }
}


extension Router {
    
    private func getStoryboard(named name: String) -> UIStoryboard {
    
        return UIStoryboard.init(name: name, bundle: .main)
    }
}


extension Router {
    
    private func showMoviesListView() {
        let storyboard = getStoryboard(named: "MoveList")
        guard let controller = storyboard.instantiateInitialViewController() as? MovieListViewController else { return }
        let presenter = MovieListPresenter(controller: controller)
        let interactor = MovieListInteractor(presenter: presenter)
        controller.interactor = interactor
        
        self.navigationController.pushViewController(controller, animated: true)
    }
}
