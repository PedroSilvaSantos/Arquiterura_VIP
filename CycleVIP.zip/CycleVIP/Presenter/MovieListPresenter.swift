//
//  MovieListPresenter.swift
//  CycleVIP
//
//  Created by Pedro Silva Dos Santos on 19/10/21.
//

import Foundation

class MovieListPresenter {
    private weak var controller: MovieListViewController?
    
    init(controller: MovieListViewController) {
        self.controller = controller
    }
}

extension MovieListPresenter {
    
    func updateView(withMovie movies: [Movie]) {
        DispatchQueue.main.async {
            guard let controller = self.controller else { return }
            var props = controller.props
            props.movies = movies
            controller.render(props: props)
        }
    }
    
    func updateViewForNoData() {
        DispatchQueue.main.async {
            guard let controller = self.controller else { return }
            var props = controller.props
            props.error = true
            controller.render(props: props)
        }
    }
}
