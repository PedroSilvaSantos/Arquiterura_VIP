//
//  MovieListViewController.swift
//  CycleVIP
//
//  Created by Pedro Silva Dos Santos on 19/10/21.
//

import UIKit

class MovieListViewController: UIViewController {
    
    @IBOutlet private var tableview: UITableView!
    private(set) var props: viewModelProps = .default //viewModel
    public var interactor: MovieListInteractor?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableview.dataSource = self
        self.tableview.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        interactor?.getMovies()
    }
}

extension MovieListViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return props.movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableview.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as? MovieCell else { fatalError("Cannot dequeue MovieCell")}
        
        
        let movie  = self.props.movies[indexPath.row]
        cell.render(props: .init(title: movie.title, year: movie.year))
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

extension MovieListViewController {
    
    struct viewModelProps {
        var movies: [Movie]
        var error: Bool
        
        static let `default`: Self = .init(movies: [], error: false)
    }
    
    public func render(props: viewModelProps) {
        self.props = props
        
        guard self.isViewLoaded else { return }
        self.tableview.reloadData()
        
        if props.error {
            self.showErrorPopUp()
        }
    }
    
    private func showErrorPopUp() {
        let alert = UIAlertController(title: nil, message: "No movies found", preferredStyle: .alert)
        
        alert.addAction(.init(title: "Ok", style: .default, handler: { (_) in
        }))
        self.present(alert, animated: true)
    }
}
