//
//  Movie.swift
//  CycleVIP
//
//  Created by Pedro Silva Dos Santos on 19/10/21.
//

import Foundation

struct Movie: Codable {
    var title: String
    var year: Int
    var imgRating: Float
}
