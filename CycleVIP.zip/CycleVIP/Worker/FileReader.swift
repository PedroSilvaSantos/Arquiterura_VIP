//
//  FileReader.swift
//  CycleVIP
//
//  Created by Pedro Silva Dos Santos on 19/10/21.
//

import Foundation

final class FileReader {
    public static func getMovies(callback: @escaping (Result<[Movie], FileReaderError>) -> Void) {
        guard let bundleUrlString = Bundle.main.url(forResource: "Movies", withExtension: "json") else { return }
        
        do {
            let data = try Data(contentsOf: bundleUrlString)
            let movies = try JSONDecoder().decode([Movie].self, from: data)
            callback(.success(movies))
        } catch {
            callback(.failure(FileReaderError()))
        }
    }
}

class FileReaderError: Error {
    init() {}
    
    func presenteError(withKey key: String) {
        print("Error:" + key)
    }
}
