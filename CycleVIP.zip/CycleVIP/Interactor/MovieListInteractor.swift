//
//  MovieListInteractor.swift
//  CycleVIP
//
//  Created by Pedro Silva Dos Santos on 19/10/21.
//

import Foundation

class MovieListInteractor {
    
    private var presenter: MovieListPresenter
    
    init(presenter: MovieListPresenter) {
        self.presenter = presenter
    }
}

extension MovieListInteractor {
    func getMovies() {
        FileReader.getMovies { result in
            guard case var .success(movies) = result
            else {
                //self.presenter.updateViewForNoData()
                return
            }
            movies = self.processMovies(movies: movies)
            self.presenter.updateView(withMovie: movies)
        }
    }
}

extension MovieListInteractor {
    func processMovies(movies: [Movie]) -> [Movie] {
        //aplicando regras de negocios no array de medias e retornando o array com novos valores
        return movies.filter { movie in
            movie.imgRating > 8.0
        }
    }
}
